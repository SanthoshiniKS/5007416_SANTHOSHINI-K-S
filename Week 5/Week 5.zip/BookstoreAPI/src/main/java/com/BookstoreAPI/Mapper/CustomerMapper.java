package com.BookstoreAPI.Mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.BookstoreAPI.DTO.CustomerDTO;
import com.BookstoreAPI.Entity.Customer;

@Mapper
public interface CustomerMapper {
	CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

	CustomerDTO customerToCustomerDTO(Customer customer);

	Customer customerDTOToCustomer(CustomerDTO customerDTO);
}

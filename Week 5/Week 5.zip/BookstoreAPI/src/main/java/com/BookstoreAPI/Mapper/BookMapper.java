package com.BookstoreAPI.Mapper;

import org.springframework.stereotype.Component;

import com.BookstoreAPI.DTO.BookDTO;
import com.BookstoreAPI.Entity.Book;

@Component
public interface BookMapper {

	BookDTO toDto(Book book);

	Book toEntity(BookDTO bookDTO);
}

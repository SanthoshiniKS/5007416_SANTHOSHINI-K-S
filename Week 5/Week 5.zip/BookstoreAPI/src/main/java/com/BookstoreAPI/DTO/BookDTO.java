package com.BookstoreAPI.DTO;

import com.BookstoreAPI.Serializer.PriceSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

public class BookDTO {
	private int id;
	@NotBlank(message = "Title is mandatory")
	private String title;

	@NotBlank(message = "Author is mandatory")
	private String author;

	@NotNull(message = "Price is mandatory")
	@Positive(message = "Price must be positive")
	@JsonSerialize(using = PriceSerializer.class)
	private Double price;

	@NotBlank(message = "ISBN number is mandatory")
	@Pattern(regexp = "\\d+", message = "ISBN must be a number")
	private String isbn;

	// Default constructor
	public BookDTO() {
	}

	// Parameterized constructor
	public BookDTO(int id, String title, String author, double price, String isbn) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.price = price;
		this.isbn = isbn;
	}

	// Getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
}

package com.example.BookstoreAPI;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.BookstoreAPI.Controller.BookController;
import com.BookstoreAPI.DTO.BookDTO;
import com.BookstoreAPI.Service.BookService;

@WebMvcTest(BookController.class)
public class BookControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BookService bookService;

	@Test
	public void testCreateBook() throws Exception {
		BookDTO bookDTO = new BookDTO();
		bookDTO.setTitle("Book Title");
		bookDTO.setAuthor("Author");
		bookDTO.setPrice(10.0);

		when(bookService.createBook(any(BookDTO.class))).thenReturn(bookDTO);

		mockMvc.perform(post("/books").contentType(MediaType.APPLICATION_JSON)
				.content("{\"title\":\"Book Title\", \"author\":\"Author\", \"price\":10.0}"))
				.andExpect(status().isCreated()).andExpect(jsonPath("$.title").value("Book Title"))
				.andExpect(jsonPath("$.author").value("Author")).andExpect(jsonPath("$.price").value(10.0));
	}
}

package com.example.EmployeeManagementSystem.Service;
import com.example.EmployeeManagementSystem.*;
import com.example.EmployeeManagementSystem.Repository.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }
    public List<Employee> getEmployeesByDepartment(String department) {
    	/*With Pagination
	 		Pageable pageable=PageRequest.of(page,size); 
	 		return employeeRepository.findByDepartment(department,pageable);
	 */
        return employeeRepository.findByDepartment(department);
    }
    public Optional<Employee> getEmployeeById(String id) {
        return employeeRepository.findById(id);
    }

    public List<Employee> getEmployeesByName(String Name) {
    	/*With Pagination
   	 		Pageable pageable=PageRequest.of(page,size); 
   	 		return employeeRepository.findByName(Name,pageable);
    	 */
        return employeeRepository.findByName(Name);
    }

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(String id) {
        employeeRepository.deleteById(id);
    }
}

package com.BookstoreAPI.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookstoreAPI.Entity.Book;
import com.BookstoreAPI.Repository.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository bookrepository;

	public void save(Book b) {
		bookrepository.save(b);
	}

	public List<Book> getAllBook() {
		return bookrepository.findAll();
	}

	public Book getBookbyId(int id) {
		return bookrepository.findById(id).get();
	}
}

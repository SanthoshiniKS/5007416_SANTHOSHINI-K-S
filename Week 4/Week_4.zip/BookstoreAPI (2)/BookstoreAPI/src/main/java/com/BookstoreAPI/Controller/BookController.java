package com.BookstoreAPI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BookstoreAPI.Entity.Book;
import com.BookstoreAPI.Entity.MyBookList;
import com.BookstoreAPI.Service.BookService;
import com.BookstoreAPI.Service.MyBookListService;

@Controller
public class BookController {

	@Autowired
	private BookService service;

	@Autowired
	private MyBookListService myBookService;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/add_book")
	public String addBooks() {
		return "add_book";
	}

	@GetMapping("/available_books")
	public ModelAndView getAllBooks() {
		List<Book> list = service.getAllBook();
		/*
		 * ModelAndView mv=new ModelAndView(); mv.setViewName("bookList");
		 * mv.addObject("book",list);
		 */
		return new ModelAndView("BookList", "book", list);
	}

	@GetMapping("/search")
	public ResponseEntity<List<Book>> searchBooks(@RequestParam(required = false) String title,
			@RequestParam(required = false) String author) {
		List<Book> books = service.searchBooks(title, author);
		return new ResponseEntity<>(books, HttpStatus.OK);
	}

	@PostMapping("/save")
	public String addBook(@ModelAttribute Book b) {
		service.save(b);
		return "redirect:/available_books";
	}

	@GetMapping("/my_books")
	public String getMyBooks(Model model) {
		List<MyBookList> list = myBookService.getAllMyBooks();
		model.addAttribute("book", list);
		return "myBooks";
	}

	@RequestMapping("/mybooklist/{id}")
	public String getMyBookList(@PathVariable("id") int id) {
		Book b = service.getBookbyId(id);
		MyBookList myb = new MyBookList(b.getId(), b.getTitle(), b.getAuthor(), b.getPrice(), b.getIsbn());
		myBookService.saveMyBooks(myb);
		return "redirect:/my_books";
	}
}
